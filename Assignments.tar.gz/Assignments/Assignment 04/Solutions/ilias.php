<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>ILIAS - zentrale E-Learning-Plattform der Universität Freiburg - solutions</title>
	
	
	
	
	
	
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />

	<link rel="apple-touch-startup-image" href="./templates/default/images/logo/ilias_logo_startup_320x460.png" /><!-- Startup image -->
	<link rel="apple-touch-icon-precomposed" href="./templates/default/images/logo/ilias_logo_57x57-precomposed.png" /><!-- iphone -->
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="./templates/default/images/logo/ilias_logo_72x72-precomposed.png" /><!-- ipad -->
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="./templates/default/images/logo/ilias_logo_114x114-precomposed.png" /><!-- iphone retina -->

	
	<link rel="stylesheet" type="text/css" href="./Services/UICore/lib/yamm3/yamm/yamm.css" media="screen" />
	
	<link rel="stylesheet" type="text/css" href="./Services/YUI/js/2_9_0/container/assets/skins/sam/container.css" media="screen" />
	
	<link rel="stylesheet" type="text/css" href="./Services/Calendar/css/panel_min.css" media="screen" />
	
	<link rel="stylesheet" type="text/css" href="./Services/UIComponent/Tooltip/lib/qtip_3_0_3/jquery.qtip.min.css" media="screen" />
	
	<link rel="stylesheet" type="text/css" href="./Services/Accordion/css/accordion.css" media="screen" />
	
	<link rel="stylesheet" type="text/css" href="./Services/Accordion/lib/owl.carousel.2.0.0-beta.2.4/assets/owl.carousel.css" media="screen" />
	
	<link rel="stylesheet" type="text/css" href="./Customizing/global/plugins/Services/UIComponent/UserInterfaceHook/CtrlMainMenu/templates/css/ctrlmm.css" media="screen" />
	
	<link rel="stylesheet" type="text/css" href="./Services/MediaObjects/media_element_2_14_2/mediaelementplayer.min.css" media="screen" />
	
	<link rel="stylesheet" type="text/css" href="Services/Notifications/templates/default/osd.css" media="screen" />
	
	
	<link rel="stylesheet" type="text/css" href="./Customizing/global/skin/unifr5x/unifr5x.css?vers=5-2-3-2017-04-05" />
	
	<!-- <link rel="P3Pv1" href="" /> -->
	<link rel="stylesheet" type="text/css" href="templates/default/delos_cont.css?vers=5-2-3-2017-04-05" />
	
	
	
	<script type="text/javascript" src="./Services/jQuery/js/2_2_4/jquery-min.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/jQuery/js/ui_1_12_0/jquery-ui-min.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/jQuery/js/jquery.outside.events.min.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/jQuery/js/jquery.ui.touch-punch.min.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/JavaScript/js/Basic.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/UICore/lib/bootstrap-3.2.0/dist/js/bootstrap.min.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/YUI/js/2_9_0/yahoo-dom-event/yahoo-dom-event.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/YUI/js/2_9_0/connection/connection-min.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/UIComponent/AdvancedSelectionList/js/AdvancedSelectionList.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/UIComponent/Modal/js/Modal.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/YUI/js/2_9_0/container/container-min.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/Notes/js/ilNotes.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/Tagging/js/ilTagging.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/UIComponent/Tooltip/lib/qtip_3_0_3/jquery.qtip.min.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/UIComponent/Tooltip/js/ilTooltip.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/YUI/js/2_9_0/container/container_core-min.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/UIComponent/Overlay/js/ilOverlay.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/Help/js/ilHelp.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/Link/lib/linkify/1_1/jquery.linkify.min.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/Link/js/ilExtLink.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/OnScreenChat/js/onscreenchat-menu.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/Contact/BuddySystem/js/buddy_system.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./libs/composer/components/moment/min/moment-with-locales.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/OnScreenChat/js/moment.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Modules/Chatroom/chat/node_modules/socket.io/node_modules/socket.io-client/socket.io.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/OnScreenChat/js/chat.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/OnScreenChat/js/onscreenchat.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/Awareness/js/Awareness.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/MediaObjects/media_element_2_14_2/mediaelement-and-player.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="Services/Notifications/templates/default/notifications.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/Accordion/js/accordion.js?vers=5-2-3-2017-04-05"></script>
	<script type="text/javascript" src="./Services/Accordion/lib/owl.carousel.2.0.0-beta.2.4/owl.carousel.js?vers=5-2-3-2017-04-05"></script>
	
</head>
<body class="std"  >
<!-- drag_zmove used, e.g. in learnin modules to drag layout borders -->
<div id="drag_zmove"></div>
<div id="unifrLeftBanner"><a href="http://www.uni-freiburg.de/"><div id="unifrLeftBannerLogo"></div></a></div>
<div id="unifrContent">
<div id="ilAll"><div id="ilTopBar" class="ilTopBar ilTopFixed hidden-print">
	<div class="container-fluid ilContainerWidth">
		<div class="row">
			
			<div class="ilTopTitle">Zentrale Lernplattform der Universität Freiburg</div>
			<div class="ilTopSubtitle">Albert-Ludwigs-Universität Freiburg</div>
			
			
			
				
				<ul id="ilTopBarNav" class="">					
					
						<li><a class="glyph" href="ilias.php?baseClass=ilMailGUI" aria-label="Mail">


<span class="glyphicon 












glyphicon-envelope




" aria-hidden="true"></span>







</a>
</li>
					
					
					
					<li class="ilOnScreenChatMenuDropDown" data-onscreenchat-header-menu><a class="glyph" aria-label="-comments-" id="il_ui_fw_592db3af08bc98_57204834">


<span class="glyphicon 
















glyphicon-comment
" aria-hidden="true"></span>



<span class="badge badge-notify il-counter-status">0</span>










<span class="badge badge-notify il-counter-novelty">0</span>






</a>
</li>
<div id="onscreenchatmenu-head" class="hide">
</div>
<div id="onscreenchatmenu-content-container" class="hide">
	<div id="onscreenchatmenu-content">
		<img class="ilOnScreenChatMenuLoader" src="./templates/default/images/loader.svg"/>
	</div>
</div>
					<li class="ilAwarenessDropDown" id="awareness_trigger">
	<a class="glyph" href="#" aria-label="-show_who_is_online-">


<span class="glyphicon 











glyphicon-user





" aria-hidden="true"></span>



<span class="badge badge-notify il-counter-status">2</span>









<span class="il-counter-spacer">2</span>


</a>

</li>
<div id="awareness-head" class="hide">
</div>
<div id="awareness-content-container" class="hide">
	<div id="awareness-content">
	<img class="ilAwarenessLoader" src="./templates/default/images/loader.svg" />
	</div>
</div>
					<li id="ilMMSearch" class="dropdown yamm"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-search"></span></a>
<ul class="dropdown-menu pull-right" role="menu">
	<li>
		<form class="" role="search" id="mm_search_form" action="ilias.php?baseClass=ilSearchController&cmd=post&rtoken=c0b578644b5b16fca91fc705c1fbbd19&fallbackCmd=remoteSearch" method="post" target="_top">
		<div class="input-group">
			<input id="main_menu_search" class="form-control" type="text" name="queryString">
			<span class="input-group-btn">
				<input type="submit" class="btn btn-default" type="button" value="Go" />
			</span>
		</div>
			<div class="yui-skin-sam" style="font-size: 75%;" id=""></div>
			
			<div id="ilMMSearchMenu">
				<p>	» <a target="_top" href="ilias.php?baseClass=ilSearchController">Letztes Suchergebnis</a></p>
				<p><input type="radio" name="root_id" value="1" checked="checked" id="ilmmsg" /> <label for="ilmmsg"> Im gesamten Magazin</label><br />
				
				<input type="radio" name="root_id" value="818072" id="ilmmsc" /> <label for="ilmmsc"> An der aktuellen Position</label></p>
				
				
				
			</div>
			
			<div id="mm_search_menu_ac"></div>
			<script type="text/javascript">
				il.Util.addOnLoad(
						function()
						{
							if (typeof $ != "undefined")
							{
								// we must bind the blur event before the autocomplete
								// item is added
								$("#main_menu_search").on("blur", function(e) {
									// prevent that the autocomplete list disappears when blur occurs
									e.stopImmediatePropagation();
								});

								$("#main_menu_search").autocomplete({
									source: "ilias.php?baseClass=ilSearchController&cmd=autoComplete" + "&search_type=4",
									appendTo: "#mm_search_menu_ac",
									open: function(event, ui) {
										$(".ui-autocomplete").position({
											my: "left top",
											at: "left top",
											of: $("#mm_search_menu_ac")
										})
									},
									/*close: function(event, ui) {
									 alert("close");
									 console.log(event);
									 console.log(ui);
									 return false;
									 },*/
									minLength: 3
								});


								$("#ilMMSearchMenu input[type='radio']").change(function(){
									$("#main_menu_search").focus();
                                                                        
                                                                        /* close current search */
                                                                        $("#main_menu_search").autocomplete("close");
                                                                        
                                                                        /* append search type */
                                                                        
                                                                        var orig_datasource = "ilias.php?baseClass=ilSearchController&cmd=autoComplete";
                                                                        var type_val = $('input[name=root_id]:checked','#mm_search_form').val();
                                                                        
                                                                        $("#main_menu_search").autocomplete("option",
                                                                        {
                                                                            source: orig_datasource + "&search_type=" + type_val
                                                                        });
                                                                        
                                                                        /* start new search */
                                                                        $("#main_menu_search").autocomplete("search");
								});
							}
						}
				);
			</script>
		</form>



	<!-- <form class="navbar-form navbar-right" role="search" action="ilias.php?baseClass=ilSearchController&cmd=post&rtoken=c0b578644b5b16fca91fc705c1fbbd19&fallbackCmd=remoteSearch" method="post" target="_top">
	<div class="form-group">
		<div class="input-group">
			<input type="text" class="form-control" placeholder="Search" name="queryString">
			<span class="input-group-btn">
				<button type="submit" class="btn btn-default"><span class="glyphicon glyphicon-search"></span></button>
			</span>
		</div>
	</div>
	</form> -->
</li></ul>
</li>

					
					<li id="mm_help" class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<span class="visible-xs-inline glyphicon glyphicon-question-sign"></span>
						<span class="hidden-xs">Hilfe <span class="caret"></span></span></a>
						<ul class="dropdown-menu pull-right" role="menu">




<li class=""><a href="#" target="_top"  onclick="il.Help.listHelp(event, false);"><span>&nbsp;</span> Themen</a></li>





<li class=""><a href="#" target="_top"  onclick="return il.Help.switchTooltips(event);"><span id="help_tt_switch_on" class="glyphicon glyphicon-ok"></span> Hilfe-Tooltips</a></li>










</ul>


					</li>
					
					
					<li id="userlog" class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
							<span><img src="./templates/default/images/no_photo_xsmall.jpg" alt="Jochen Sautter" title="Jochen Sautter" border="0"/><!--Jochen Sautter--><span class="caret"></span></span>
						</a>
						<ul class="dropdown-menu pull-right" role="menu">
							<li>
								<a href="ilias.php?baseClass=ilPersonalDesktopGUI&cmd=jumpToProfile" target="_top">Persönliche Daten und Profil</a>
							</li>
							<li>
								<a href="ilias.php?baseClass=ilPersonalDesktopGUI&cmd=jumpToSettings" target="_top">Einstellungen</a>
							</li>
							<li role="presentation" class="divider"></li>
							<li>
								<a href="logout.php?lang=de"><i>Jochen Sautter</i> - Abmeldung</a>
							</li>
						</ul>
					</li>
					
					
					

				</ul>
				
		</div>
	</div>
</div>
<script type="text/javascript">
	var OSDNotifier;
	$(function () {
		OSDNotifier = OSDNotifications({
			closeHtml:            "<span class=\"sr-only\">Schlie\u00dfen<\/span><span class=\"glyphicon glyphicon-remove\"><\/span>",
			initialNotifications: [],
			pollingIntervall:     120,
			playSound:            false
		});
	});
	</script>
<div class="osdNotificationContainer"></div>

<div class="ilMainHeader ilTopFixed hidden-print">
	<header class="container-fluid ilContainerWidth">
		<div class="row">
			<a class="navbar-brand" href="ilias.php?baseClass=ilPersonalDesktopGUI&cmd=jumpToSelectedItems" target="_top">
				<img src="./templates/default/images/HeaderIcon.svg" alt="Logo" class="noMirror" /></a>
		</div>
	</header>
</div>
<div class="ilMainMenu ilTopFixed hidden-print">
<div class="container-fluid ilContainerWidth">
	<div class="row">
		<nav id="ilTopNav" class="navbar navbar-default" role="navigation">
			
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#ilMainMenuEntries">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<!-- <a class="navbar-brand" href="#">Brand</a> -->
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="ilMainMenuEntries">
					<ul class='ilias5 ilMainMenu  nav navbar-nav' id="">
	<li class="ilMainMenu dropdown" >
    <a id="mm_1_tr"  class="MMInactive" data-toggle="dropdown" href="#" target="_top">Persönlicher Schreibtisch
    
    <span class="caret"></span>
    </a>

    <ul class="dropdown-menu" role="menu">




<li class=""><a href="ilias.php?baseClass=ilPersonalDesktopGUI&amp;cmd=jumpToSelectedItems" target="_top" id="mm_pd_sel_items" >Übersicht</a></li>





<li class=""><a href="ilias.php?baseClass=ilPersonalDesktopGUI&amp;cmd=jumpToMemberships" target="_top" id="mm_pd_crs_grp" >Meine Kurse und Gruppen</a></li>





<li class=""><a href="ilias.php?baseClass=ilPersonalDesktopGUI&amp;cmd=jumpToBookmarks" target="_top" id="mm_pd_bookm" >Bookmarks</a></li>





<li class=""><a href="ilias.php?baseClass=ilPersonalDesktopGUI&amp;cmd=jumpToNotes" target="_top" id="mm_pd_notes" >Notizen und Kommentare</a></li>





<li class=""><a href="ilias.php?baseClass=ilPersonalDesktopGUI&amp;cmd=jumpToNews" target="_top" id="mm_pd_news" >Neuigkeiten</a></li>




<li class="divider"></li>






<li class=""><a href="ilias.php?baseClass=ilPersonalDesktopGUI&amp;cmd=jumpToWorkspace" target="_top" id="mm_pd_wsp" >Mein Arbeitsraum</a></li>





<li class=""><a href="ilias.php?baseClass=ilPersonalDesktopGUI&amp;cmd=jumpToPortfolio" target="_top" id="mm_pd_port" >Portfolio</a></li>




<li class="divider"></li>






<li class=""><a href="ilias.php?baseClass=ilPersonalDesktopGUI&amp;cmd=jumpToCalendar" target="_top" id="mm_pd_cal" >Kalender</a></li>





<li class=""><a href="ilias.php?baseClass=ilMailGUI" target="_top" id="mm_pd_mail" >Mail</a></li>





<li class=""><a href="ilias.php?baseClass=ilPersonalDesktopGUI&amp;cmd=jumpToContacts" target="_top" id="mm_pd_contacts" >Kontakte</a></li>




<li class="divider"></li>






<li class=""><a href="ilias.php?baseClass=ilPersonalDesktopGUI&amp;cmd=jumpToProfile" target="_top" id="mm_pd_profile" >Persönliche Daten und Profil</a></li>





<li class=""><a href="ilias.php?baseClass=ilPersonalDesktopGUI&amp;cmd=jumpToSettings" target="_top" id="mm_pd_sett" >Einstellungen</a></li>










</ul>


</li><li class="ilMainMenu dropdown" >
    <a id="mm_2_tr"  class="MMActive" data-toggle="dropdown" href="#" target="_top">Magazin
    
    <span class="caret"></span>
    </a><span class='ilAccHidden'>(Ausgewählt)</span>

    <ul class="dropdown-menu" role="menu">




<li class=""><a href="https://ilias.uni-freiburg.de/goto.php?target=root_1&client_id=unifreiburg" target="_top"  ><img src="./templates/default/images/icon_root.svg" border="0"/> Magazin - Einstiegsseite</a></li>



<li class="dropdown-header ilLVNavEnt">Zuletzt besucht</li>







<li class="ilLVNavEnt"><a href="ilias.php?ref_id=818120&amp;cmd=infoScreen&amp;cmdClass=ilrepositorygui&amp;cmdNode=ue&amp;baseClass=ilRepositoryGUI" target="_top"  ><img src="./templates/default/images/icon_file.svg" border="0"/> 3.3 Logistic Regression Vs LDA.ipynb</a></li>





<li class="ilLVNavEnt"><a href="ilias.php?ref_id=818121&amp;cmd=infoScreen&amp;cmdClass=ilrepositorygui&amp;cmdNode=ue&amp;baseClass=ilRepositoryGUI" target="_top"  ><img src="./templates/default/images/icon_file.svg" border="0"/> 3.1 Least Square Linear Regression.ipynb</a></li>





<li class="ilLVNavEnt"><a href="ilias.php?ref_id=818122&amp;cmd=infoScreen&amp;cmdClass=ilrepositorygui&amp;cmdNode=ue&amp;baseClass=ilRepositoryGUI" target="_top"  ><img src="./templates/default/images/icon_file.svg" border="0"/> 3.2 Linear Regression with Gradient Descent.ipynb</a></li>





<li class="ilLVNavEnt"><a href="https://ilias.uni-freiburg.de/goto.php?target=crs_772957&client_id=unifreiburg" target="_top"  ><img src="./templates/default/images/icon_crs.svg" border="0"/> Machine Learning SS2017</a></li>





<li class="ilLVNavEnt"><a href="ilias.php?baseClass=ilRepositoryGUI&amp;cmd=showThreads&amp;ref_id=773005" target="_top"  ><img src="./templates/default/images/icon_frm.svg" border="0"/> Discussion Forum</a></li>





<li class="ilLVNavEnt"><a href="https://ilias.uni-freiburg.de/goto.php?target=file_818050&client_id=unifreiburg" target="_top"  ><img src="./templates/default/images/icon_file.svg" border="0"/> lecture07_algorithm_independent_principles_part1.p…</a></li>





<li class="ilLVNavEnt"><a href="https://ilias.uni-freiburg.de/goto.php?target=file_818049&client_id=unifreiburg" target="_top"  ><img src="./templates/default/images/icon_file.svg" border="0"/> lecture07_algorithm_independent_principles_part1_4…</a></li>





<li class="ilLVNavEnt"><a href="https://ilias.uni-freiburg.de/goto.php?target=file_812035&client_id=unifreiburg" target="_top"  ><img src="./templates/default/images/icon_file.svg" border="0"/> lecture06_linear_subspace_projections_ICA.pdf</a></li>





<li class="ilLVNavEnt"><a href="https://ilias.uni-freiburg.de/goto.php?target=tst_809065&client_id=unifreiburg" target="_top"  ><img src="./templates/default/images/icon_tst.svg" border="0"/> dritter online-Test (vierte Vorlesungswoche)</a></li>





<li class="ilLVNavEnt"><a href="https://ilias.uni-freiburg.de/goto.php?target=crs_755738&client_id=unifreiburg" target="_top"  ><img src="./templates/default/images/icon_crs.svg" border="0"/> Mathematik II für Studierende der Informatik</a></li>





<li class="ilLVNavEnt"><a href="#" target="_top"  onclick="return il.MainMenu.removeLastVisitedItems('ilias.php?cmd=removeEntries&cmdClass=ilnavigationhistorygui&cmdNode=iq&baseClass=ilnavigationhistorygui&cmdMode=asynch');">» Einträge löschen</a></li>










</ul>


</li><li class="ilMainMenu dropdown" >
    <a id="mm_6_tr"  class="MMInactive" data-toggle="dropdown" href="#" target="_top">Dokumentation und Tutorials
    
    <span class="caret"></span>
    </a>

    <ul class="dropdown-menu" role="menu">




<li class=""><a href="https://ilias.uni-freiburg.de/goto.php?target=frm_235&client_id=unifreiburg" target="_top" id="mm_pd_sel_items8" >Online-Forum: Fragen zu ILIAS</a></li>





<li class=""><a href="https://ilias.uni-freiburg.de/goto.php?target=lm_221303&client_id=unifreiburg" target="_top" id="mm_pd_sel_items10" >Lernmodul: ILIAS Dokumentation für Lehrende und Kursadmins</a></li>
<li class=""><span></span></li>




<li class=""><a href="https://ilias.uni-freiburg.de/goto.php?target=cat_10540&client_id=unifreiburg" target="_top" id="mm_pd_sel_items9" >Anleitungen und Videotutorials für Lehrende</a></li>





<li class=""><a href="https://ilias.uni-freiburg.de/goto.php?target=cat_700637&client_id=unifreiburg" target="_top" id="mm_pd_sel_items11" >Aktuelle Infos zu urheberrechtlich geschützten Schriftwerken ab 1.1.2017</a></li>





<li class=""><a href="https://ilias.uni-freiburg.de/ilias.php?cmd=showPublicProfile&cmdClass=ilpersonalprofilegui&cmdNode=sg:sh&baseClass=ilPersonalDesktopGUI" target="_top" id="mm_pd_sel_items19" >Eigenes Nutzer*innen-Profil (de-)aktivieren</a></li>
<li class=""><span></span></li>









</ul>


</li><li class="ilMainMenu dropdown" >
    <a id="mm_13_tr"  class="MMInactive" data-toggle="dropdown" href="#" target="_top">Lerngruppen
    
    <span class="caret"></span>
    </a>

    <ul class="dropdown-menu" role="menu">




<li class=""><a href="https://ilias.uni-freiburg.de/ilias.php?baseClass=ilRepositoryGUI&ref_id=766027&cmd=create&new_type=grp" target="_top" id="mm_pd_sel_items14" >Neue Lerngruppe anlegen</a></li>





<li class=""><a href="https://ilias.uni-freiburg.de/goto.php?target=cat_766027" target="_top" id="mm_pd_sel_items16" >Bestehende Lerngruppen anzeigen</a></li>





<li class=""><a href="https://ilias.uni-freiburg.de/ilias.php?cmd=showPublicProfile&cmdClass=ilpersonalprofilegui&cmdNode=sg:sh&baseClass=ilPersonalDesktopGUI" target="_top" id="mm_pd_sel_items15" >Eigenes Nutzer*innenprofil aktivieren</a></li>
<li class=""><span></span></li>









</ul>


</li>
</ul>
					
				</div><!-- /.navbar-collapse -->
			
		</nav>

		
		
	</div>
</div>
</div>






<a  class="ilTreeView" href="ilias.php?baseClass=ilRepositoryGUI&amp;cmd=frameset&amp;set_mode=tree&amp;ref_id=818072" target="_top" id="imgtree">
	<img id="ilSideBarIcon" src="./Customizing/global/skin/unifr5x/images/icon_sidebar_on.svg" alt="Baumansicht ein" title="Baumansicht ein" /></a>

<div id="mainspacekeeper" class="container-fluid ilContainerWidth ilFixedTopSpacer">
	<div class="row" style="position: relative;">
	
	<div id="fixed_content" class=" ilContentFixed" >
		<div id="mainscrolldiv" >
			<h2 class="ilAccHidden">Brotkrumen-Navigation</h2>
<ol class="breadcrumb hidden-print">
	
	
	<!-- <img src="./templates/default/images/icon_root.svg" alt="Magazin - Einstiegsseite" border="0" /> --><li><a href="ilias.php?ref_id=1&amp;cmd=frameset&amp;cmdClass=ilrepositorygui&amp;cmdNode=ue&amp;baseClass=ilrepositorygui"  target="_top" >Magazin</a></li>
	
	
	
	
	<!-- <img src="./templates/default/images/icon_cat.svg" alt="Kategorie" border="0" /> --><li><a href="ilias.php?ref_id=722588&amp;cmd=frameset&amp;cmdClass=ilrepositorygui&amp;cmdNode=ue&amp;baseClass=ilrepositorygui"  target="_top" >Lehrveranstaltungen im SoSe 2017</a></li>
	
	
	
	
	<!-- <img src="./templates/default/images/icon_cat.svg" alt="Kategorie" border="0" /> --><li><a href="ilias.php?ref_id=724355&amp;cmd=frameset&amp;cmdClass=ilrepositorygui&amp;cmdNode=ue&amp;baseClass=ilrepositorygui"  target="_top" >Technische Fakultät</a></li>
	
	
	
	
	<!-- <img src="./templates/default/images/icon_cat.svg" alt="Kategorie" border="0" /> --><li><a href="ilias.php?ref_id=724357&amp;cmd=frameset&amp;cmdClass=ilrepositorygui&amp;cmdNode=ue&amp;baseClass=ilrepositorygui"  target="_top" >Studiengang Informatik/Angewandte Informatik</a></li>
	
	
	
	
	<!-- <img src="./templates/default/images/icon_cat.svg" alt="Kategorie" border="0" /> --><li><a href="ilias.php?ref_id=724394&amp;cmd=frameset&amp;cmdClass=ilrepositorygui&amp;cmdNode=ue&amp;baseClass=ilrepositorygui"  target="_top" >Master - Spezialisierung PO-Version 2011</a></li>
	
	
	
	
	<!-- <img src="./templates/default/images/icon_cat.svg" alt="Kategorie" border="0" /> --><li><a href="ilias.php?ref_id=724397&amp;cmd=frameset&amp;cmdClass=ilrepositorygui&amp;cmdNode=ue&amp;baseClass=ilrepositorygui"  target="_top" >Kognitive technische Systeme</a></li>
	
	
	
	
	<!-- <img src="./templates/default/images/icon_crs.svg" alt="Kurs" border="0" /> --><li><a href="ilias.php?ref_id=772957&amp;cmd=frameset&amp;cmdClass=ilrepositorygui&amp;cmdNode=ue&amp;baseClass=ilrepositorygui"  target="_top" >Machine Learning SS2017</a></li>
	
	
	
	
	<!-- <img src="./templates/default/images/icon_fold.svg" alt="Ordner" border="0" /> --><li><a href="ilias.php?ref_id=773040&amp;cmd=frameset&amp;cmdClass=ilrepositorygui&amp;cmdNode=ue&amp;baseClass=ilrepositorygui"  target="_top" >Assignments</a></li>
	
	
	
	
	<!-- <img src="./templates/default/images/icon_fold.svg" alt="Ordner" border="0" /> --><li><a href="ilias.php?ref_id=809511&amp;cmd=frameset&amp;cmdClass=ilrepositorygui&amp;cmdNode=ue&amp;baseClass=ilrepositorygui"  target="_top" >Assignment 04</a></li>
	
	
	
	
	<!-- <img src="./templates/default/images/icon_fold.svg" alt="Ordner" border="0" /> --><li><a href="ilias.php?ref_id=818072&amp;cmd=frameset&amp;cmdClass=ilrepositorygui&amp;cmdNode=ue&amp;baseClass=ilrepositorygui"  target="_top" >solutions</a></li>
	
	
</ol>

			
	
	
	<div class="media il_HeaderInner">
		
		<div class="ilHeadAction hidden-print" id="il_head_action">
			<div id="tttt" style="white-space:nowrap;"> 
<div class="btn-group">
<!-- Important: The next a-tag had a this.blur(); in the onclick event before. Please do not add it again, see bug #8723 -->
<button type="button"  class="btn btn-sm btn-default dropdown-toggle" data-toggle="dropdown" data-container="body" id="ilAdvSelListAnchorText_act_818072_pref_818072">
<span><span class='hidden-xs'>Aktionen</span></span> <span class="caret"></span>
</button>


<ul class="dropdown-menu pull-right" role="menu" id="ilAdvSelListTable_act_818072_pref_818072">
	
	
	
	<li onclick="return il.AdvancedSelectionList.openTarget('ilias.php?ref_id=818072&amp;item_ref_id=818072&amp;active_node=818072&amp;type=fold&amp;cmd=addToDesk&amp;cmdClass=ilobjfoldergui&amp;cmdNode=ue:lq&amp;baseClass=ilrepositorygui','');">
	<a id="act_818072_pref_818072_" href="ilias.php?ref_id=818072&amp;item_ref_id=818072&amp;active_node=818072&amp;type=fold&amp;cmd=addToDesk&amp;cmdClass=ilobjfoldergui&amp;cmdNode=ue:lq&amp;baseClass=ilrepositorygui" ><span class="xsmall">Auf Schreibtisch legen</span></a>
	</li>
	
	<li onclick="return il.AdvancedSelectionList.openTarget('ilias.php?ref_id=818072&amp;cmd=enableMultiDownload&amp;cmdClass=ilobjfoldergui&amp;cmdNode=ue:lq&amp;baseClass=ilrepositorygui','');">
	<a id="act_818072_pref_818072_" href="ilias.php?ref_id=818072&amp;cmd=enableMultiDownload&amp;cmdClass=ilobjfoldergui&amp;cmdNode=ue:lq&amp;baseClass=ilrepositorygui" ><span class="xsmall">Mehrere Objekte herunterladen</span></a>
	</li>
	
	<li onclick="return ilNotes.listNotes(event, '1;818072;fold;980473;;0', 'il.Object.redrawActionHeader();');;">
	<a id="act_818072_pref_818072_" href="#" ><span class="xsmall">Notizen</span></a>
	</li>
	
	<li onclick="return ilTagging.listTags(event, '1;818072;fold;980473;;0', 'il.Object.redrawActionHeader();');;">
	<a id="act_818072_pref_818072_" href="#" ><span class="xsmall">Tags setzen</span></a>
	</li>
	
	
	
</ul>

</div>
<script type="text/javascript">
il.AdvancedSelectionList.init['act_818072_pref_818072'] = function ()
{
	il.AdvancedSelectionList.add('act_818072_pref_818072', {"trigger_event":"click","auto_hide":false,"anchor_id":"ilAdvSelListAnchorElement_act_818072_pref_818072","asynch":false,"asynch_url":"","toggle_el":"lg_div_818072_pref_818072","toggle_class_on":"ilContainerListItemOuterHighlight"});
	
	il.AdvancedSelectionList.addItem('act_818072_pref_818072', '', '', 'Auf Schreibtisch legen');
	
	il.AdvancedSelectionList.addItem('act_818072_pref_818072', '', '', 'Mehrere Objekte herunterladen');
	
	il.AdvancedSelectionList.addItem('act_818072_pref_818072', '', '', 'Notizen');
	
	il.AdvancedSelectionList.addItem('act_818072_pref_818072', '', '', 'Tags setzen');
	
	
};
il.AdvancedSelectionList.init['act_818072_pref_818072']();


</script>
</div>

		</div>
		
		<div class="ilHeadAction hidden-print" id="il_head_action">
			
		</div>
		
		
		
			
			<img id="headerimage" class="media-object" src="./templates/default/images/icon_fold.svg" alt="Symbol Ordner" title="Symbol Ordner" />
			
				<h1 class="media-heading ilHeader"><a class="ilAccAnchor" id="il_mhead_t_focus" name="il_mhead_t_focus" >solutions</a></h1>
		
		<div class="media-body">
	
	
		</div>
	</div>
	
    
	
	
	
	<div class="ilClearFloat"></div>

<h2 class="ilAccHeadingHidden">Reiter</h2>
<ul id="ilTab" class="nav nav-tabs ilCollapsable hidden-print" role="tablist">
	
	
	
	<li id="tab_view_content" class="active"><a href="ilias.php?ref_id=818072&amp;cmdClass=ilobjfoldergui&amp;cmdNode=ue:lq&amp;baseClass=ilrepositorygui" target="">Inhalt</a> <span class="ilAccHidden">(Ausgewählt)</span></li>
	
	<li id="tab_info_short" class=""><a href="ilias.php?ref_id=818072&amp;cmd=showSummary&amp;cmdClass=ilinfoscreengui&amp;cmdNode=ue:lq:dy&amp;baseClass=ilrepositorygui" target="">Info</a></li>
	
	<li id="ilLastTab">
		<a class="btn dropdown-toggle ilNoDisplay" data-toggle="dropdown" href="#">
			... <span class="caret"></span>
		</a>
		<ul class="dropdown-menu" id="ilTabDropDown">
		</ul>
	</li>
</ul>
<span class="ilAccHidden"><a id="after_tabs" name="after_tabs"></a></span>

<div class="ilTabsContentOuter"><div class="clearfix"></div>

<span class="ilAccHidden"><a id="after_sub_tabs" name="after_sub_tabs"></a></span>



<div>
	
	
</div>

<div class="container-fluid" id="ilContentContainer">
	<div class="row">

		<div id="il_center_col" class="col-sm-12">
			
			
			
			

<div  id="bl_cntr_1" class="ilContainerBlock container-fluid form-inline">
	
	
	
	<div class="row ilContainerBlockHeader">
		
		<h3 class="ilHeader ilContainerBlockHeader">Inhalt</h3>
		<div class="pull-right"></div>
	</div>
	
	
	
	
	
	
	
	
	<div  class="ilCLI ilObjListRow row">
	
	
		<div class="ilContainerListItemOuter" id = "lg_div_818074_pref_818072">



<div class="ilContainerListItemIcon "><a href="https://ilias.uni-freiburg.de/goto.php?target=file_818074_download&client_id=unifreiburg" ><img alt="Symbol Datei" title="Symbol Datei" src="./templates/default/images/icon_file.svg" class="ilListItemIcon" /></a></div>
<div class="ilContainerListItemContent ">
<div class="il_ContainerListItem">
	<div class="il_ContainerItemTitle form-inline">
		
		
		
		
		<h4 class="il_ContainerItemTitle"><a href="https://ilias.uni-freiburg.de/goto.php?target=file_818074_download&client_id=unifreiburg" class="il_ContainerItemTitle"  >4.1 PCA</a></h4>
		
		
	</div>
	<div style="float:right">
		
	</div>
	
	<div class="ilFloatRight">
	
<div class="btn-group">
<!-- Important: The next a-tag had a this.blur(); in the onclick event before. Please do not add it again, see bug #8723 -->
<button type="button"  class="btn btn-sm btn-default dropdown-toggle" data-toggle="dropdown" data-container="body" id="ilAdvSelListAnchorText_act_818074_pref_818072">
<span></span> <span class="caret"></span>
</button>


<ul class="dropdown-menu pull-right" role="menu" id="ilAdvSelListTable_act_818074_pref_818072">
	
	<li><img src="./templates/default/images/loader.svg" alt="loading" /></li>
	
	
	
</ul>

</div>
<script type="text/javascript">
il.AdvancedSelectionList.init['act_818074_pref_818072'] = function ()
{
	il.AdvancedSelectionList.add('act_818074_pref_818072', {"trigger_event":"click","auto_hide":false,"anchor_id":"ilAdvSelListAnchorElement_act_818074_pref_818072","asynch":true,"asynch_url":"ilias.php?ref_id=818072&cmdrefid=818074&cmd=getAsynchItemList&cmdClass=ilobjfoldergui&cmdNode=ue:lq&baseClass=ilrepositorygui&cmdMode=asynch","toggle_el":"lg_div_818074_pref_818072","toggle_class_on":"ilContainerListItemOuterHighlight"});
	
	
};
il.AdvancedSelectionList.init['act_818074_pref_818072']();


$("#ilAdvSelListAnchorText_act_818074_pref_818072").click(function() {
	il.Util.ajaxReplaceInner('ilias.php?ref_id=818072&cmdrefid=818074&cmd=getAsynchItemList&cmdClass=ilobjfoldergui&cmdNode=ue:lq&baseClass=ilrepositorygui&cmdMode=asynch', 'ilAdvSelListTable_act_818074_pref_818072');
	$(this).unbind("click");
});	

</script>

	</div>
	
	
	<div class="ilListItemSection il_Description"></div>
	
	
	
	<div class="ilListItemSection il_ItemProperties">
	
		
		
		<span class="il_ItemProperty">
		
		ipynb&nbsp;&nbsp;</span>
	
		
		
		<span class="il_ItemProperty">
		
		165,1 KB&nbsp;&nbsp;</span>
	
		
		
		<span class="il_ItemProperty">
		
		Gestern, 11:44&nbsp;&nbsp;</span>
	
	</div>
	
	
	
	
	
	
	
	
	<div style="clear:both;"></div>
</div>

<div style="clear:both;"></div>
</div>
</div>

	</div>
	
	
	
	
	
	
	
	
	
</div>


			
			
			
		</div>

		

		
	</div>
</div>




</div>

</div>
</div>
</div>
</div>
<div id="minheight"></div>
<footer id="ilFooter" class="ilFooter hidden-print"><div class="container-fluid ilContainerWidth">
		<div class="row"><div class="ilFooterContainer"><label for="current_perma_link">
	<a href="https://ilias.uni-freiburg.de/goto.php?target=fold_818072&client_id=unifreiburg" onclick="with(document.getElementById('current_perma_link')){focus();select();} return false;" class="permalink_label">Link zu dieser Seite:</a>
</label>&nbsp;
<input id="current_perma_link" type="text" value="https://ilias.uni-freiburg.de/goto.php?target=fold_818072&client_id=unifreiburg" readonly="readonly" onclick="this.focus();this.select();return false;" />

<div class="btn-group">
<!-- Important: The next a-tag had a this.blur(); in the onclick event before. Please do not add it again, see bug #8723 -->
<button type="button"  class="btn btn-sm btn-default dropdown-toggle" data-toggle="dropdown" data-container="body" id="ilAdvSelListAnchorText_socialbm_actions_643c820d8920190cc5298f447bd27e7a">
<span></span> <span class="caret"></span>
</button>


<ul class="dropdown-menu pull-right" role="menu" id="ilAdvSelListTable_socialbm_actions_643c820d8920190cc5298f447bd27e7a">
	
	
	
	<li onclick="return il.AdvancedSelectionList.openTarget('ilias.php?cmd=redirect&baseClass=ilPersonalDesktopGUI&redirectClass=ilbookmarkadministrationgui&redirectCmd=newFormBookmark&param_bmf_id=1&param_return_to=true&param_bm_title=solutions&param_bm_link=https%253A%252F%252Filias.uni-freiburg.de%252Fgoto.php%253Ftarget%253Dfold_818072%2526client_id%253Dunifreiburg&param_return_to_url=%252Filias.php%253Fref_id%253D818072%2526cmd%253Dview%2526cmdClass%253Dilrepositorygui%2526cmdNode%253Due%2526baseClass%253Dilrepositorygui','_top');">
	<a id="socialbm_actions_643c820d8920190cc5298f447bd27e7a_" href="ilias.php?cmd=redirect&baseClass=ilPersonalDesktopGUI&redirectClass=ilbookmarkadministrationgui&redirectCmd=newFormBookmark&param_bmf_id=1&param_return_to=true&param_bm_title=solutions&param_bm_link=https%253A%252F%252Filias.uni-freiburg.de%252Fgoto.php%253Ftarget%253Dfold_818072%2526client_id%253Dunifreiburg&param_return_to_url=%252Filias.php%253Fref_id%253D818072%2526cmd%253Dview%2526cmdClass%253Dilrepositorygui%2526cmdNode%253Due%2526baseClass%253Dilrepositorygui" target="_top"><span >Zu ILIAS-Bookmarks hinzufügen</span></a>
	</li>
	
	
	
</ul>

</div>
<script type="text/javascript">
il.AdvancedSelectionList.init['socialbm_actions_643c820d8920190cc5298f447bd27e7a'] = function ()
{
	il.AdvancedSelectionList.add('socialbm_actions_643c820d8920190cc5298f447bd27e7a', {"trigger_event":"click","auto_hide":false,"anchor_id":"ilAdvSelListAnchorElement_socialbm_actions_643c820d8920190cc5298f447bd27e7a","asynch":false,"asynch_url":false});
	
	il.AdvancedSelectionList.addItem('socialbm_actions_643c820d8920190cc5298f447bd27e7a', '', '', 'Zu ILIAS-Bookmarks hinzufügen');
	
	
};
il.AdvancedSelectionList.init['socialbm_actions_643c820d8920190cc5298f447bd27e7a']();


</script>
&nbsp; <bdo class="" dir="ltr">powered by ILIAS (v5.2.3 2017-04-05) on web1</bdo> | 

<a href="https://ilias.uni-freiburg.de/goto.php?target=impr_0&client_id=unifreiburg" target="_blank">Kontakt & Impressum</a>
 | 

<a href="ilias.php?cmdClass=ilsystemsupportcontactsgui&amp;cmdNode=zi&amp;baseClass=ilsystemsupportcontactsgui">ILIAS-Systemadministration kontaktieren</a>




</div></div></div></footer>

</div>
</div>

<script type="text/javascript">
	il.Util.addOnLoad(function() {
		il.Object.setRedrawListItemUrl('ilias.php?ref_id=818072&cmd=redrawListItem&cmdClass=ilobjfoldergui&cmdNode=ue:lq&baseClass=ilrepositorygui&cmdMode=asynch');
		il.Object.setRatingUrl('ilias.php?ref_id=818072&cmd=saveRating&cmdClass=ilratinggui&cmdNode=ue:lq:73:u3&baseClass=ilrepositorygui&cmdMode=asynch');
		il.Language.setLangVar('private_notes', "Private Notizen");
		il.Language.setLangVar('notes_public_comments', "\u00d6ffentliche Kommentare");
		ilNotes.setAjaxUrl('ilias.php?ref_id=818072&active_node=818072&cmdClass=ilnotegui&cmdNode=ue:lq:73:j0&baseClass=ilrepositorygui&cmdMode=asynch');
		il.Language.setLangVar('tagging_tags', "Tags");
		ilTagging.setAjaxUrl('ilias.php?ref_id=818072&active_node=818072&cmdClass=iltagginggui&cmdNode=ue:lq:73:zq&baseClass=ilrepositorygui&cmdMode=asynch');
		il.Object.setRedrawAHUrl('ilias.php?ref_id=818072&active_node=818072&cmd=redrawHeaderAction&cmdClass=ilobjfoldergui&cmdNode=ue:lq&baseClass=ilrepositorygui&cmdMode=asynch');
		il.Tooltip.add("tab_view_content", { context:"tab_view_content", my:"bottom center", at:"top center", text:"Lerninhalte und -aktivitäten im Ordner" } );
		il.Tooltip.add("tab_info_short", { context:"tab_info_short", my:"bottom center", at:"top center", text:"Erstellungsdatum und den Link zum Objekt einsehen, als Bookmark speichern und Tags vergeben" } );
		il.Overlay.add("mm_search_menu", {"yuicfg":{"visible":false,"fixedcenter":false},"trigger":null,"trigger_event":null,"anchor_id":null,"auto_hide":false,"close_el":null}); 
		il.Tooltip.add("help_tr", { context:"help_tr", my:"bottom center", at:"top center", text:"Online-Hilfe öffnen" } );
		il.Tooltip.add("help_tt", { context:"help_tt", my:"bottom center", at:"top center", text:"Hilfe-Tooltips an-/ausschalten" } );
		il.Help.setAjaxUrl('ilias.php?help_screen_id=fold/view_content/.818072&cmdClass=ilhelpgui&cmdNode=db&baseClass=ilhelpgui&cmdMode=asynch');
		il.Language.setLangVar('chat_osc_conversations', "Konversationen");
		il.Language.setLangVar('chat_osc_section_head_other_rooms', "\u00d6ffentlicher Chatraum");
		il.Language.setLangVar('chat_osc_sure_to_leave_grp_conv', "Sind Sie sicher, dass Sie die Gruppenkonversation verlassen m\u00f6chten?");
		il.Language.setLangVar('chat_osc_user_left_grp_conv', "Der Benutzer '%s' hat die Gruppenkonversation verlassen.");
		il.Language.setLangVar('confirm', "Best\u00e4tigen");
		il.Language.setLangVar('cancel', "Abbrechen");
		il.Language.setLangVar('chat_osc_leave_grp_conv', "Konversation verlassen");
		il.Language.setLangVar('chat_osc_no_conv', "Keine Konversationen vorhanden.");
		il.Language.setLangVar('chat_osc_dont_accept_msg', "Sie k\u00f6nnen aktuell von anderen Personen nicht zu Konversationen eingeladen werden. Dies k\u00f6nnen Sie bei Bedarf in Ihren <a href=\"ilias.php?cmd=showChatOptions&amp;cmdClass=ilpersonalchatsettingsformgui&amp;cmdNode=sg:si:sf&amp;baseClass=ilpersonaldesktopgui\">'Pers\u00f6nlichen Einstellungen'<\/a> \u00e4ndern.");
		
		il.OnScreenChatMenu.setConfig({"conversationTemplate":"<div class=\"ilOnScreenChatMenuItem\" data-onscreenchat-menu-item data-onscreenchat-conversation=\"[[conversationId]]\">\n\t<div class=\"media\">\n\t\t<div class=\"media-left\" style=\"position:relative;\">\n\t\t\t<a href=\"#\">\n\t\t\t\t[[badge]]\n\t\t\t\t<img class=\"media-object\" data-onscreenchat-avatar=\"[[userId]]\" src=\"[[avatar]]\" alt=\"\" \/>\n\t\t\t<\/a>\n\t\t<\/div>\n\t\t<div class=\"media-body online\">\n\t\t\t<h4 class=\"media-heading\"><strong title=\"[[participants]]\">[[participants]]<\/strong><\/h4>\n\t\t\t<span class=\"btn btn-secondary close pull-right\"><span data-onscreenchat-menu-remove-conversation class=\"glyphicon glyphicon-remove\"><\/span><\/span>\n\t\t\t<p class=\"lastMessage\" data-onscreenchat-body-last-msg>[[last_message]]<\/p>\n\t\t\t<p>\n\t\t\t\t<small data-livestamp=\"[[last_message_time_raw]]\">[[last_message_time]]<\/small>\n\t\t\t<\/p>\n\t\t<\/div>\n\t<\/div>\n<\/div>\n","roomTemplate":"<div class=\"ilOnScreenChatMenuItem\">\n\t<div class=\"media\">\n\t\t<div class=\"media-left\">\n\t\t\t<a href=\"[[url]]\">\n\t\t\t\t<img class=\"media-object\" src=\"[[icon]]\" alt=\"\" \/>\n\t\t\t<\/a>\n\t\t<\/div>\n\t\t<div class=\"media-body\">\n\t\t\t<h4 class=\"media-heading\">&nbsp;<\/h4>\n\t\t\t<p><a href=\"[[url]]\" title=\"[[name]]\">[[name]]<\/a><\/p>\n\t\t<\/div>\n\t<\/div>\n<\/div>\n","infoTemplate":"<div class=\"ilOnScreenChatMenuItem\">\n\t<div class=\"media\">\n\t\t<div class=\"media-body info\">[[html]]<\/div>\n\t<\/div>\n<\/div>\n","userId":"952384","rooms":[],"showAcceptMessageChange":true,"showOnScreenChat":"1","triggerId":"il_ui_fw_592db3af08bc98_57204834","conversationNoveltyCounter":"\n\n\n<span class=\"badge badge-notify il-counter-novelty\">0<\/span>\n\n"});
		il.OnScreenChatMenu.init();
		il.BuddySystem.setConfig({"http_post_url":"ilias.php?cmd=post&cmdClass=ilbuddysystemgui&cmdNode=12k:4t&baseClass=iluipluginroutergui&cmdMode=asynch&rtoken=c0b578644b5b16fca91fc705c1fbbd19","transition_state_cmd":"transitionAsync"});
		il.BuddySystemButton.setConfig({"bnt_class":"ilBuddySystemLinkWidget"});
		il.BuddySystemButton.init();
		il.Language.setLangVar('chat_osc_no_usr_found', "Es konnte kein Benutzer gefunden werden.");
		il.Language.setLangVar('chat_osc_emoticons', "Emoticons");
		il.Language.setLangVar('chat_osc_write_a_msg', "Verfasse eine Nachricht ...");
		il.Language.setLangVar('autocomplete_more', "mehr");
		il.Language.setLangVar('close', "Schlie\u00dfen");
		il.Language.setLangVar('chat_osc_invite_to_conversation', "Zu Konversation hinzuf\u00fcgen");
		il.Language.setLangVar('chat_osc_user', "Benutzer");
		il.Language.setLangVar('chat_osc_add_user', "Weitere Benutzer zum Chat hinzuf\u00fcgen");
		il.Chat.setConfig({"url":"https:\/\/ilias.uni-freiburg.de:8181\/unifreiburg-im","subDirectory":"\/socket.io","userId":"952384","username":"js1285_uni-freiburg"});
		il.OnScreenChat.setConfig({"chatWindowTemplate":"<div class=\"col-md-2 chat-window-wrapper pull-right\" data-onscreenchat-window=\"[[conversationId]]\">\n\t<div class=\"panel panel-primary\">\n\t\t<div class=\"panel-heading\" data-onscreenchat-header>\n\t\t\t<img src=\".\/templates\/default\/images\/icon_chta.svg\" border=\"0\"\/> <span class=\"osc_truncate_username\" data-toggle=\"tooltip\" data-placement=\"left\" title=\"[[participants]]\" data-onscreenchat-window-participants>[[participants]]<\/span>\n\t\t\t<div class=\"btn-group pull-right\">\n\t\t\t\t<a class=\"glyph\" href=\"addUser\" aria-label=\"Hinzuf\u00fcgen\">\n\n\n<span class=\"glyphicon \n\n\n\nglyphicon-plus-sign\n\n\n\n\n\n\n\n\n\n\n\n\n\n\" aria-hidden=\"true\"><\/span>\n\n\n\n\n\n\n\n<\/a>\n\n\t\t\t\t<button type=\"button\" class=\"close\" data-dismiss=\"modal\">\n\t<span aria-hidden=\"true\">&times;<\/span>\n\t<span class=\"sr-only\">Close<\/span>\n<\/button>\n\n\t\t\t<\/div>\n\t\t<\/div>\n\t\t<div class=\"panel-body\">\n\t\t\t<ul class=\"chat\" data-onscreenchat-body><\/ul>\n\t\t<\/div>\n\t\t<div class=\"panel-footer\">\n\t\t\t<div class=\"input-group\">\n\t\t\t\t<div class=\"form-control iosOnScreenChatMessagePlaceholder\" data-onscreenchat-message-placeholder>#:#chat_osc_write_a_msg#:#<\/div>\n\t\t\t\t<div class=\"form-control iosOnScreenChatMessage\" spellcheck=\"true\" data-onscreenchat-message contenteditable=\"true\"><\/div>\n\t\t\t\t<span class=\"input-group-btn\"><a class=\"btn btn-default\" href=\"onscreenchat-submit\" data-action=\"onscreenchat-submit\">Senden<\/a>\n<\/span>\n\t\t\t<\/div>\n\t\t\t<div class=\"ilNoDisplay\" data-onscreenchat-emoticons><\/div>\n\t\t<\/div>\n\t<\/div>\n<\/div>\n","messageTemplate":"<ul>\n\t<li class=\"left clearfix\">\n\t\t<span class=\"chat-img pull-left\">\n\t\t\t<img data-onscreenchat-avatar=\"[[userId]]\" src=\"[[avatar]]\" alt=\"User Avatar\">\n\t\t<\/span>\n\t\t<div class=\"chat-body clearfix\">\n\t\t\t<div class=\"header\">\n\t\t\t\t<strong class=\"primary-font\" title=\"[[username]]\"><span class=\"osc_truncate_username_right\">[[username]]<\/span><\/strong><br>\n\t\t\t\t<small class=\"pull-left text-muted-right\"><span class=\"glyphicon glyphicon-time\"><\/span><span data-livestamp=\"[[time_raw]]\">[[time]]<\/span><\/small>\n\t\t\t<\/div><br>\n\t\t\t<p data-onscreenchat-body-msg class=\"iosOnScreenChatBodyMsg\">[[message]]<\/p>\n\t\t<\/div>\n\t<\/li>\n\t<li class=\"right clearfix\">\n        <span class=\"chat-img pull-right\">\n            <img data-onscreenchat-avatar=\"[[userId]]\" src=\"[[avatar]]\" alt=\"User Avatar\" class=\"\">\n        <\/span>\n\t\t<div class=\"chat-body clearfix\">\n\t\t\t<div class=\"header\">\n\t\t\t\t<strong class=\"pull-right primary-font\" title=\"[[username]]\"><span class=\"osc_truncate_username_left\">[[username]]<\/span><\/strong><br>\n\t\t\t\t<small class=\"pull-right text-muted-left\"><span class=\"glyphicon glyphicon-time\"><\/span><span data-livestamp=\"[[time_raw]]\">[[time]]<\/span><\/small>\n\t\t\t<\/div><br>\n\t\t\t<p data-onscreenchat-body-msg class=\"iosOnScreenChatBodyMsg\">[[message]]<\/p>\n\t\t<\/div>\n\t<\/li>\n<\/ul>","modalTemplate":"<div class=\"iosOnScreenChatModalBody\" data-onscreenchat-modal-body=\"[[conversationId]]\">\n\t<div>\n\t\t<p><label for=\"invite_user_text_[[conversationId]]\">#:#chat_osc_user#:#:<\/label>\n\t\t\t<input type=\"text\" class=\"form-control\" id=\"invite_user_text_[[conversationId]]\" data-onscreenchat-usersearch\/>\n\t\t<\/p>\n\t\t<div class=\"ilNoDisplay alert alert-info\" role=\"alert\" data-onscreenchat-no-usr-found>#:#chat_osc_no_usr_found#:#<\/div>\n\t<\/div>\n<\/div>","userId":"952384","username":"js1285_uni-freiburg","userListURL":"ilias.php?cmd=getUserList&cmdClass=ilonscreenchatgui&cmdNode=px&baseClass=ilonscreenchatgui&cmdMode=asynch","userProfileDataURL":"ilias.php?cmd=getUserProfileImages&cmdClass=ilonscreenchatgui&cmdNode=px&baseClass=ilonscreenchatgui&cmdMode=asynch","verifyLoginURL":"ilias.php?cmd=verifyLogin&cmdClass=ilonscreenchatgui&cmdNode=px&baseClass=ilonscreenchatgui&cmdMode=asynch","loaderImg":".\/templates\/default\/images\/loader.svg","emoticons":[],"locale":"de"});
		il.OnScreenChat.init();
		il.Awareness.setBaseUrl('ilias.php?ref_id=818072&cmdClass=ilawarenessgui&cmdNode=3v&baseClass=ilawarenessgui&cmdMode=asynch');
		il.Awareness.setLoaderSrc('./templates/default/images/loader.svg');
		il.Awareness.init();
		il.Tooltip.add("mm_pd_sel_items", { context:"mm_pd_sel_items", my:"left center", at:"right center", text:"Schnellzugriff auf ausgewählte Angebote" } );
		il.Tooltip.add("mm_pd_crs_grp", { context:"mm_pd_crs_grp", my:"left center", at:"right center", text:"Zeigt den aktuellen Stand der Gruppen- und Kursmitgliedschaften, Kalendereinträge, Nachrichten, Chat oder Bookmarks auf einen Blick und listet alle Mitgliedschaften auf." } );
		il.Tooltip.add("mm_pd_bookm", { context:"mm_pd_bookm", my:"left center", at:"right center", text:"Lesezeichen anlegen, ansehen oder verwalten" } );
		il.Tooltip.add("mm_pd_notes", { context:"mm_pd_notes", my:"left center", at:"right center", text:"Private Notizen und öffentliche Kommentare lesen und verfassen" } );
		il.Tooltip.add("mm_pd_news", { context:"mm_pd_news", my:"left center", at:"right center", text:"Nachrichten aus Kursen und Gruppen im Überblick, mit Hilfe eines Links zum jeweiligen ILIAS-Bereich der Nachricht wechseln" } );
		il.Tooltip.add("mm_pd_wsp", { context:"mm_pd_wsp", my:"left center", at:"right center", text:"Eigene Inhalte erstellen und zur Nutzung für andere Benutzer freigeben, freigegebene Inhalte anderer Benutzer einsehen" } );
		il.Tooltip.add("mm_pd_port", { context:"mm_pd_port", my:"left center", at:"right center", text:"Portfolios erstellen und für andere Benutzer freigeben, Portfolios anderer Benutzer ansehen" } );
		il.Tooltip.add("mm_pd_cal", { context:"mm_pd_cal", my:"left center", at:"right center", text:"ILIAS-Terminkalender erstellen und einsehen, Sprechstundenangebote anlegen und verwalten" } );
		il.Tooltip.add("mm_pd_mail", { context:"mm_pd_mail", my:"left center", at:"right center", text:"ILIAS-interne Mails empfangen und versenden, Verteilerlisten einrichten" } );
		il.Tooltip.add("mm_pd_contacts", { context:"mm_pd_contacts", my:"left center", at:"right center", text:"Andere Benutzer in einem Adressbuch speichern oder in Verteilerlisten zusammenfassen" } );
		il.Tooltip.add("mm_pd_profile", { context:"mm_pd_profile", my:"left center", at:"right center", text:"Persönliche Daten verwalten und ggf. in einem Profil veröffentlichen" } );
		il.Tooltip.add("mm_pd_sett", { context:"mm_pd_sett", my:"left center", at:"right center", text:"Sprach-, Zeit- und Anzeigeeinstellungen anpassen, ILIAS-Passwort ändern und Mail-Signatur festlegen" } );
		
	});
</script>

<script type="text/javascript">
	il.Util.addOnLoad(function() {
		il.Tooltip.init();
		
	});
</script>

</body>
</html>

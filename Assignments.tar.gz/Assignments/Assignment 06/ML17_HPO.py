
# coding: utf-8

# In[1]:

import numpy as np

from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

from robo.fmin import bayesian_optimization


import logging
logging.basicConfig(level=logging.INFO)




# load dataset and create train-test split
data = load_digits()
X_train, X_test, y_train, y_test = train_test_split(data['data'], data['target'],                                                    test_size=0.2)


# let's try the default Support Vector Classifier
classifier = SVC()
classifier.fit(X_train, y_train)
yhat = classifier.predict(X_test)
default_acc = accuracy_score(y_test, yhat)



def parametrized_SVC(conf):
    C, gamma = conf
    classifier = SVC(C=C, gamma=gamma)
    classifier.fit(X_train, y_train)

    yhat = classifier.predict(X_test)
    # note the minus, because RoBO minimizes!
    return(-accuracy_score(y_test, yhat))



def log_parametrized_SVC(conf):
    C, gamma = np.exp(conf)
    classifier = SVC(C=C, gamma=gamma)
    classifier.fit(X_train, y_train)

    yhat = classifier.predict(X_test)
    # note the minus, because RoBO minimizes!
    return(-accuracy_score(y_test, yhat))


num_iterations = 10

lower = np.array([0, 0])
upper = np.array([1000, 1000])

results = bayesian_optimization(parametrized_SVC, lower, upper, num_iterations=num_iterations)

# let's try a different parametrization

log_lower = np.array([-20, -20])
log_upper = np.array([10, 10])

log_results = bayesian_optimization(log_parametrized_SVC, log_lower, log_upper, num_iterations=num_iterations)


print('default accuracy = %f'%default_acc)
print('after %d iterations, the best accuracy found was %f'%(num_iterations, -results["f_opt"]))
print('the corresponding configuration is C={:.2e} and gamma={:.2e}'.format(*results['x_opt']))
print('after %d iterations, the best accuracy found using log-scales was %f'%(num_iterations, -log_results["f_opt"]))
print('the corresponding configuration is C={:.2e} and gamma={:.2e}'.format(*np.exp(log_results['x_opt'])))




